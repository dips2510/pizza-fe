const initialState = {
  addonModal:false,
  pizzaCard:{
    selectedPizza:{},
    pizzaList:[],
  },
  order: {
    response:[],
    display:false
    }
};

export default initialState;
