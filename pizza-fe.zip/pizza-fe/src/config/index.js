import appConfig from './app.config.json';

const config = Object.assign({}, appConfig);

export default config;